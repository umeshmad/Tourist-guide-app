package bank;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.util.List;
import java.util.ArrayList;

public class Transaction extends User{
	private List<TransactionHistory>trans;
	int transactionid=000;
	public Transaction() {
		trans=new ArrayList<>();
	}
	public void addToTransaction(TransactionHistory tran) {
		trans.add(tran);
	}
	public void moneyTransAction() {
		Scanner input=new Scanner(System.in);
		String payeeAcc;
		String payeeName;
		String type;
		double payeeAmount;
		LocalDateTime currentTime=LocalDateTime.now();
		LocalDateTime time;
		
		System.out.println("Enter the accountnumber");
		payeeAcc=input.nextLine();
		System.out.println("Enter the AccountholderName");
		payeeName=input.nextLine();
		System.out.println("Enter the Amount");
		payeeAmount=input.nextDouble();
		for(CreatAccount acc:getaccounts()) {
			if(acc.getAccNumber().equals(payeeAcc)&&acc.getUsername().equals(payeeName)) {
				getusername();
				time=currentTime;
				transactionid++;
				type="Deposite";
				double balance=acc.getbalance();
				double newbalance=balance+payeeAmount;
				acc.transermoney(newbalance);
				TransactionHistory transaction=new TransactionHistory(transactionid,type,payeeAmount,time);
				addToTransaction(transaction);
			}
			
		}
	}

}
