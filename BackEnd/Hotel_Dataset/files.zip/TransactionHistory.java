package bank;
import java.io.Serializable;
import java.time.LocalDateTime;

public class TransactionHistory implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String type;
	private double amount;
	private LocalDateTime dateTime;
	private int transactionid;
	 
	public TransactionHistory(int transactionid, String type, double amount, LocalDateTime dateTime) {
		this.type = type;
		this.amount = amount;
		this.dateTime = dateTime;
		this.transactionid = transactionid;
	}
	
	public String getType() {
		return type;
	}
	
	public double getamount() {
		return amount;
	}
	
	public LocalDateTime gettime() {
		return dateTime;
	}
	
	public int getTransId() {
		return transactionid;
	}
}
