package bank;

import java.io.*;
import java.util.ArrayList;

public class readAccount {
	protected ArrayList<CreatAccount>accounts;
	public void readData() {
		try {
			ObjectInputStream ois=new ObjectInputStream(new FileInputStream("bank.dat"));
			accounts=(ArrayList<CreatAccount>)ois.readObject();
			ois.close();
		}catch(Exception e) {
			e.printStackTrace();
		}
		
	}	
}
