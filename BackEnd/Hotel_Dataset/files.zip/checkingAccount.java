package bank;
import java.util.Scanner;

public class checkingAccount extends CreatAccount{
	private String status;
	Scanner input=new Scanner(System.in);
	public void setAccountStatus() {
		System.out.println("Enter the Account Status");
		String Y=input.nextLine();
		status=Y;
			
	}
	public String getStatus() {
		return status;
	}
	
	public void creatAccount(String username) {
		setUsername(username);
		setAccNum();
		setBalance();
		setPin();
		setAccountStatus();
		System.out.println("Account Status : "+getStatus());
		System.out.println("Account Name : "+getUsername());
		System.out.println("Account Number : "+getAccNumber());
		System.out.println("Account Balance is Rs."+getbalance());
		System.out.println("Account pin : "+getPin());	
	}
	public void withdraw() {
		System.out.println("Enter the withdrawel amount");
		double w=input.nextInt();
		if(getStatus().equals("New")) {
			double b=-1000;
			double z=getbalance()-w;
			if(z>=b) {
				balance-=w;
				System.out.println("Withdraw Success");
			}else {
				System.out.println("Can not proceed the withdrawel");
			}
		}else if(getStatus().equals("Reguler")) {
			double b=-5000;
			double z=getbalance()-w;
			if(z>=b) {
				balance-=w;
				System.out.println("Withdraw Success");
			}else {
				System.out.println("Can not proceed the withdrawel");
			}	
		}else {
			double b=-10000;
			double z=getbalance()-w;
			if(z>=b) {
				balance-=w;
				System.out.println("Withdraw Success");
			}else {
				System.out.println("Can not proceed the withdrawel");
			}
		}
	}
	public void Deposite() {
		deposite();
	}

}
