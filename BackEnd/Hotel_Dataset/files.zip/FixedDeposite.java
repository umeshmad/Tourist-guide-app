package bank;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

public class FixedDeposite extends CreatAccount {
	private Long durationMonths;
	private LocalDate startDate;
	transient Scanner input = new Scanner(System.in);
	LocalDate currentDate=LocalDate.now();
	
	public void setMonths() {
		System.out.println("Enter the deposite months");
		Long R=input.nextLong();
		durationMonths=R;
	}
	public Long getMonths() {
		return durationMonths;
	}
	public void setMonthsReflect(Long months) {
	    this.durationMonths = months;
	}
	
	public void setStartMonths() {
		startDate=currentDate;
		
	}
	public LocalDate getStartMonths() {
		return startDate;
	}
	public void creatAccount(String username) {
		setUsername(username);
		setAccNum();
		setBalance();
		setMonths();
		setPin();
		
		System.out.println("Account Name : "+getUsername());
		System.out.println("Account Number : "+getAccNumber());
		System.out.println("Account Balance is Rs."+getbalance());
		System.out.println("Fixed Monthes"+getMonths());
		System.out.println("Account pin : "+getPin());	
	}
	public void withdraw() {
		double interstMoney=0;
		Long difference = ChronoUnit.MONTHS.between(startDate, currentDate);
		if(difference>=durationMonths) {
			System.out.println("You can withdraw your money SucessFully");
		}else {
			System.out.println("Not Completed the deposite dutation ");
			System.out.println("Withdrawal will incur a penalty. Do you wan to continue if yes press 1 else press 2");
			System.out.println("1. Yes");
			System.out.println("2. No");
			int e=input.nextInt();
			if(e==1) {
				double currentbalance=getbalance();
				for(int i=0; i<difference; i++) {
					interstMoney=(getbalance()/100)*2;
					reduceInterstBalance(interstMoney);
				}
				System.out.println("Panlty amount is Rs."+(currentbalance-getbalance()));
				
			}else {
				System.out.println("Thnak you");
			}
			
		}
	}
	public void interstRate() {
		double interstMoney=0;
		Long difference = ChronoUnit.MONTHS.between(startDate, currentDate);
		if(difference<=3) {
			for(int count=1; count<difference; count++) {
				interstMoney=(getbalance()/100)*7;
				setInterstBalance(interstMoney);
				
			}
			interstMoney=0;
		}else if(difference<=6){
			for(int count=1; count<difference; count++) {
				interstMoney=(getbalance()/100)*8;
				setInterstBalance(interstMoney);
			}
			interstMoney=0;	
		}else if(difference<=12) {
			for(int count=1; count<difference; count++) {
				interstMoney=(getbalance()/100)*10;
				setInterstBalance(interstMoney);
			}
			interstMoney=0;	
		}else if(difference<=24) {
			for(int count=1; count<difference; count++) {
				interstMoney=(getbalance()/100)*12.5;
				setInterstBalance(interstMoney);
			}
			interstMoney=0;	
		}else if(difference<48) {
			for(int count=1; count<difference; count++) {
				interstMoney=(getbalance()/100)*15;
				setInterstBalance(interstMoney);
			}
			interstMoney=0;	
		}else {
			for(int count=1; count<difference; count++) {
				interstMoney=(getbalance()/100)*20;
				setInterstBalance(interstMoney);
			}
			interstMoney=0;	
		}
		
		
		
	}

}
