package bank;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class studentAccount extends CreatAccount{
	
	private String institute;
	private String studentID;
	public LocalDate startDate;

	public void setStudentId() {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the Student ID :");
		String Y=input.nextLine();
		studentID=Y;	
	}
	public String getStudentId() {
		return studentID;
	}

	public void setInstitute() {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the institute Name :");
		String X=input.nextLine();
		institute=X;
	}
	public String getInstituteName() {
		return institute;
	}
	
	public void creatAccount(String username) {
		setUsername(username);
		setAccNum();
		setInstitute();
		setStudentId();
		setBalance();
		setPin();
		System.out.println("Account Name : "+getUsername());
		System.out.println("Account Number : "+getAccNumber());
		System.out.println("Institute name : "+getInstituteName());
		System.out.println("Student ID : "+getStudentId());
		System.out.println("Account Balance is Rs."+getbalance());
		System.out.println("Account pin : "+getPin());
		startDate=LocalDate.now();
	}
	public void withdrawmoney() {
		withdraw();
	}
	public void Deposite() {
		deposite();
	}
	public void interestrate() { 
		LocalDate currentDate=LocalDate.now();
		double interstMoney;
		
		Long differance=ChronoUnit.DAYS.between(startDate,currentDate);
		
		if (differance>30) {
			int count=0;
			while(differance>=30) {
				differance=differance-30;
				count=count+1;
			}
			 for(int i = 0; i < count; i++) {
				interstMoney=(getbalance()/100)*8;
				setInterstBalance(interstMoney);
				
			}
		
			startDate=currentDate;
		}
			
	}

}
