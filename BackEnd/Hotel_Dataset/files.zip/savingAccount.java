package bank;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.Scanner;

public class savingAccount extends CreatAccount{
	public LocalDate startDate;
	public void creatAccount(String username) {
		
		setUsername(username);
		setAccNum();
		setBalance();
		setPin();
		System.out.println("Account Name : "+getUsername());
		System.out.println("Account Number : "+getAccNumber());
		System.out.println("Account Balance is Rs."+getbalance());
		System.out.println("Account pin : "+getPin());
		startDate=LocalDate.now();
	}
	
	public void withdrawmoney() {
		withdraw();
	}
	public void Deposite() {
		deposite();
	}
	public void interestrate() { 
		LocalDate currentDate=LocalDate.now();
		double interstMoney;
		
		Long differance=ChronoUnit.DAYS.between(startDate,currentDate);
		
		if (differance>30) {
			int count=0;
			while(differance>=30) {
				differance=differance-30;
				count=count+1;
			}
			 for(int i = 0; i < count; i++) {
				interstMoney=(getbalance()/100)*3;
				setInterstBalance(interstMoney);
				
			}
		
			startDate=currentDate;
		}
			
	}
}


