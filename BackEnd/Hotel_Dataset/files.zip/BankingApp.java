package bank;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.util.List;

// Main entry point - Rajarata Digital Banking Application with Swing GUI
public class BankingApp {

    // ── Colour palette ──────────────────────────────────────────────────────
    static final Color BG        = new Color(15,  23,  42);   // dark navy
    static final Color PANEL     = new Color(30,  41,  59);   // card bg
    static final Color ACCENT    = new Color(56, 189, 248);   // sky blue
    static final Color ACCENT2   = new Color(99, 236, 175);   // mint green
    static final Color TEXT      = new Color(226, 232, 240);  // light grey
    static final Color SUBTEXT   = new Color(148, 163, 184);  // muted
    static final Color DANGER    = new Color(248,  113, 113); // red

    // ── Fonts ────────────────────────────────────────────────────────────────
    static final Font FONT_TITLE  = new Font("SansSerif", Font.BOLD,  22);
    static final Font FONT_LABEL  = new Font("SansSerif", Font.BOLD,  13);
    static final Font FONT_BODY   = new Font("SansSerif", Font.PLAIN, 13);
    static final Font FONT_SMALL  = new Font("SansSerif", Font.PLAIN, 11);
    static final Font FONT_MONO   = new Font("Monospaced", Font.PLAIN, 12);

    // ── Global state ─────────────────────────────────────────────────────────
    static UserManager manager = new UserManager();
    static User currentUser    = null;

    // ── Main ──────────────────────────────────────────────────────────────────
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            manager.readData();
            showLoginFrame();
        });
    }

    // ════════════════════════════════════════════════════════════════════════
    //  LOGIN / REGISTER FRAME
    // ════════════════════════════════════════════════════════════════════════
    static void showLoginFrame() {
        JFrame frame = makeFrame("Rajarata Digital Bank", 440, 520);

        JPanel root = darkPanel();
        root.setLayout(new BorderLayout());
        root.setBorder(BorderFactory.createEmptyBorder(30, 40, 30, 40));

        // Header
        JPanel header = darkPanel();
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        JLabel logo = new JLabel("\uD83C\uDFE6", SwingConstants.CENTER);
        logo.setFont(new Font("SansSerif", Font.PLAIN, 48));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel title = makeLabel("Rajarata Digital Bank", FONT_TITLE, ACCENT);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);
        JLabel sub = makeLabel("Secure · Simple · Smart", FONT_SMALL, SUBTEXT);
        sub.setAlignmentX(Component.CENTER_ALIGNMENT);
        header.add(logo);
        header.add(Box.createVerticalStrut(8));
        header.add(title);
        header.add(Box.createVerticalStrut(4));
        header.add(sub);

        // Form card
        JPanel card = roundedCard();
        card.setLayout(new GridBagLayout());
        GridBagConstraints g = gbc();

        JLabel accLabel = makeLabel("Account Number", FONT_LABEL, TEXT);
        JTextField accField = styledField();
        JLabel pinLabel = makeLabel("PIN", FONT_LABEL, TEXT);
        JPasswordField pinField = styledPass();

        g.gridy = 0; card.add(accLabel,  g);
        g.gridy = 1; card.add(accField,  g);
        g.gridy = 2; card.add(Box.createVerticalStrut(8), g);
        g.gridy = 3; card.add(pinLabel,  g);
        g.gridy = 4; card.add(pinField,  g);
        g.gridy = 5; card.add(Box.createVerticalStrut(16), g);

        JButton loginBtn = primaryButton("Login");
        g.gridy = 6; card.add(loginBtn, g);

        JSeparator sep = new JSeparator();
        sep.setForeground(new Color(51, 65, 85));
        sep.setBackground(new Color(51, 65, 85));
        g.gridy = 7; g.insets = new Insets(14, 0, 14, 0);
        card.add(sep, g);
        g.insets = new Insets(0, 0, 0, 0);

        JButton regBtn = ghostButton("New User? Register Here");
        g.gridy = 8; card.add(regBtn, g);

        // Actions
        loginBtn.addActionListener(e -> {
            String acc = accField.getText().trim();
            String pin = new String(pinField.getPassword()).trim();
            if (acc.isEmpty() || pin.isEmpty()) { showError(frame, "Please fill all fields."); return; }
            for (User u : manager.users) {
                for (CreatAccount a : u.getaccounts()) {
                    if (a.getAccNumber().equals(acc) && a.getPin().equals(pin)) {
                        currentUser = u;
                        frame.dispose();
                        showDashboard();
                        return;
                    }
                }
            }
            showError(frame, "Incorrect Account Number or PIN.");
        });

        regBtn.addActionListener(e -> { frame.dispose(); showRegisterFrame(); });
        pinField.addActionListener(e -> loginBtn.doClick());

        root.add(header, BorderLayout.NORTH);
        root.add(Box.createVerticalStrut(20), BorderLayout.CENTER);
        root.add(card, BorderLayout.SOUTH);

        frame.add(root);
        frame.setVisible(true);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  REGISTER FRAME
    // ════════════════════════════════════════════════════════════════════════
    static void showRegisterFrame() {
        JFrame frame = makeFrame("Register New User", 440, 500);
        JPanel root = darkPanel();
        root.setLayout(new BorderLayout());
        root.setBorder(BorderFactory.createEmptyBorder(24, 40, 24, 40));

        JLabel title = makeLabel("Create Account", FONT_TITLE, ACCENT);
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JPanel card = roundedCard();
        card.setLayout(new GridBagLayout());
        GridBagConstraints g = gbc();

        JTextField nameField    = styledField();
        JTextField accField     = styledField();
        JPasswordField pinField = styledPass();
        JTextField balField     = styledField();
        String[] types = {"Savings Account", "Checking Account", "Student Account", "Fixed Deposit Account"};
        JComboBox<String> typeBox = styledCombo(types);

        g.gridy = 0; card.add(makeLabel("Create Account", FONT_TITLE, ACCENT), g);
        g.gridy = 1; card.add(Box.createVerticalStrut(12), g);
        addFormRow(card, g, 2,  "Full Name",             nameField);
        addFormRow(card, g, 4,  "Account Number",        accField);
        addFormRow(card, g, 6,  "PIN",                   pinField);
        addFormRow(card, g, 8,  "Opening Balance (Rs.)", balField);
        addFormRow(card, g, 10, "Account Type",          typeBox);

        g.gridy = 12; g.insets = new Insets(16, 0, 0, 0);
        JButton regBtn = primaryButton("Create Account");
        card.add(regBtn, g);

        g.gridy = 13; g.insets = new Insets(8, 0, 0, 0);
        JButton backBtn = ghostButton("Back to Login");
        card.add(backBtn, g);

        regBtn.addActionListener(e -> {
            String name   = nameField.getText().trim();
            String accNum = accField.getText().trim();
            String pin    = new String(pinField.getPassword()).trim();
            String balStr = balField.getText().trim();

            if (name.isEmpty() || accNum.isEmpty() || pin.isEmpty() || balStr.isEmpty()) {
                showError(frame, "Please fill all fields."); return;
            }
            double bal;
            try { bal = Double.parseDouble(balStr); } catch (Exception ex) {
                showError(frame, "Invalid balance amount."); return;
            }
            for (User u : manager.users) {
                for (CreatAccount a : u.getaccounts()) {
                    if (a.getAccNumber().equals(accNum)) {
                        showError(frame, "Account number already exists."); return;
                    }
                }
            }
            int typeIdx = typeBox.getSelectedIndex() + 1;
            CreatAccount account = buildAccount(typeIdx, name, accNum, pin, bal);
            if (account == null) { showError(frame, "Error creating account."); return; }

            User existing = null;
            for (User u : manager.users) {
                if (u.getusername().equalsIgnoreCase(name)) { existing = u; break; }
            }
            if (existing != null) {
                existing.addAccount(account);
            } else {
                User newUser = new User();
                newUser.setUsernameDirectly(name);
                newUser.addAccount(account);
                manager.users.add(newUser);
            }
            manager.saveData();
            showInfo(frame, "Account created!\nAccount Number: " + accNum);
            frame.dispose();
            showLoginFrame();
        });

        backBtn.addActionListener(e -> { frame.dispose(); showLoginFrame(); });

        JScrollPane scroll = new JScrollPane(card);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);

        root.add(scroll, BorderLayout.CENTER);
        frame.add(root);
        frame.setVisible(true);
    }

    // ════════════════════════════════════════════════════════════════════════
    //  DASHBOARD
    // ════════════════════════════════════════════════════════════════════════
    static void showDashboard() {
        JFrame frame = makeFrame("Dashboard — " + currentUser.getusername(), 720, 560);
        JPanel root = darkPanel();
        root.setLayout(new BorderLayout(0, 0));

        // ── Sidebar ──────────────────────────────────────────────────────────
        JPanel sidebar = new JPanel();
        sidebar.setBackground(PANEL);
        sidebar.setLayout(new BoxLayout(sidebar, BoxLayout.Y_AXIS));
        sidebar.setPreferredSize(new Dimension(190, 0));
        sidebar.setBorder(BorderFactory.createEmptyBorder(24, 16, 24, 16));

        JLabel userLbl = makeLabel("  " + currentUser.getusername(), FONT_LABEL, ACCENT);
        userLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(userLbl);
        sidebar.add(Box.createVerticalStrut(4));
        JLabel roleLbl = makeLabel("  Customer", FONT_SMALL, SUBTEXT);
        roleLbl.setAlignmentX(Component.LEFT_ALIGNMENT);
        sidebar.add(roleLbl);
        sidebar.add(Box.createVerticalStrut(20));

        JSeparator div = new JSeparator();
        div.setForeground(new Color(51, 65, 85));
        div.setMaximumSize(new Dimension(Integer.MAX_VALUE, 1));
        sidebar.add(div);
        sidebar.add(Box.createVerticalStrut(16));

        String[] navItems = {"  Overview", "  Deposit", "  Withdraw",
                             "  Transfer", "  Transactions", "  Statement",
                             "  New Account", "  Logout"};
        String[] keys = {"overview","deposit","withdraw","transfer","transactions","statement","newaccount","logout"};

        JPanel content = darkPanel();
        content.setLayout(new CardLayout());
        CardLayout cl = (CardLayout) content.getLayout();

        // Build all panels
        JPanel depositPanel   = buildOperationPanel("Deposit",  "deposit",  frame);
        JPanel withdrawPanel  = buildOperationPanel("Withdraw", "withdraw", frame);
        JPanel transferPanel  = buildTransferPanel(frame);
        JPanel newAccPanel    = buildNewAccountPanel(frame);

        content.add(buildOverviewPanel(),  "overview");
        content.add(depositPanel,          "deposit");
        content.add(withdrawPanel,         "withdraw");
        content.add(transferPanel,         "transfer");
        content.add(buildTxPanel(),        "transactions");
        content.add(buildStatementPanel(), "statement");
        content.add(newAccPanel,           "newaccount");

        for (int i = 0; i < navItems.length; i++) {
            final String key = keys[i];
            JButton btn = navButton(navItems[i]);
            btn.addActionListener(e -> {
                if (key.equals("logout")) {
                    currentUser = null;
                    frame.dispose();
                    showLoginFrame();
                } else {
                    // Rebuild balance panels every time so they show latest values
                    if (key.equals("overview")) {
                        content.remove(content.getComponent(0));
                        content.add(buildOverviewPanel(), "overview", 0);
                    }
                    if (key.equals("transactions")) {
                        content.remove(content.getComponent(4));
                        content.add(buildTxPanel(), "transactions", 4);
                    }
                    if (key.equals("statement")) {
                        content.remove(content.getComponent(5));
                        content.add(buildStatementPanel(), "statement", 5);
                    }
                    cl.show(content, key);
                    content.revalidate();
                    content.repaint();
                }
            });
            sidebar.add(btn);
            sidebar.add(Box.createVerticalStrut(2));
        }

        root.add(sidebar,  BorderLayout.WEST);
        root.add(content,  BorderLayout.CENTER);
        frame.add(root);
        frame.setVisible(true);
    }

    // ── Overview panel ────────────────────────────────────────────────────────
    static JPanel buildOverviewPanel() {
        JPanel p = darkPanel();
        p.setLayout(new BorderLayout());
        p.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        JLabel title = makeLabel("Account Overview", FONT_TITLE, TEXT);
        p.add(title, BorderLayout.NORTH);

        JPanel cards = new JPanel(new GridLayout(0, 2, 12, 12));
        cards.setOpaque(false);
        cards.setBorder(BorderFactory.createEmptyBorder(16, 0, 0, 0));

        for (CreatAccount acc : currentUser.getaccounts()) {
            JPanel card = roundedCard();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.add(makeLabel(acc.getClass().getSimpleName(), FONT_LABEL, ACCENT));
            card.add(Box.createVerticalStrut(6));
            card.add(makeLabel("Acc No: " + acc.getAccNumber(), FONT_SMALL, SUBTEXT));
            card.add(Box.createVerticalStrut(8));
            card.add(makeLabel("Rs. " + String.format("%.2f", acc.getbalance()), FONT_TITLE, ACCENT2));
            cards.add(card);
        }

        if (currentUser.getaccounts().isEmpty()) {
            cards.add(makeLabel("No accounts found. Open one from the sidebar.", FONT_BODY, SUBTEXT));
        }

        JScrollPane scroll = new JScrollPane(cards);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ── Deposit / Withdraw panel ──────────────────────────────────────────────
    static JPanel buildOperationPanel(String label, String op, JFrame parent) {
        JPanel p = darkPanel();
        p.setLayout(new GridBagLayout());

        JPanel card = roundedCard();
        card.setLayout(new GridBagLayout());
        GridBagConstraints g = gbc();

        List<CreatAccount> accs = currentUser.getaccounts();
        String[] accNums = accs.stream()
            .map(a -> a.getAccNumber() + "  (" + a.getClass().getSimpleName() + ")")
            .toArray(String[]::new);
        JComboBox<String> accBox = styledCombo(accNums);
        JTextField amtField = styledField();

        // Live balance label - updates immediately after transaction
        JLabel balLabel = makeLabel("", FONT_LABEL, ACCENT2);

        g.gridy = 0; card.add(makeLabel(label, FONT_TITLE, ACCENT), g);
        g.gridy = 1; card.add(Box.createVerticalStrut(12), g);
        addFormRow(card, g, 2, "Select Account", accBox);
        addFormRow(card, g, 4, "Amount (Rs.)",   amtField);
        g.gridy = 6; g.insets = new Insets(8, 0, 0, 0);
        card.add(balLabel, g);
        g.gridy = 7; g.insets = new Insets(12, 0, 0, 0);
        JButton btn = primaryButton(label);
        card.add(btn, g);

        // Show balance of selected account when dropdown changes
        Runnable refreshBal = () -> {
            if (!accs.isEmpty()) {
                CreatAccount sel = accs.get(accBox.getSelectedIndex());
                balLabel.setText("Current Balance: Rs." + String.format("%.2f", sel.getbalance()));
            }
        };
        if (!accs.isEmpty()) refreshBal.run();
        accBox.addActionListener(ev -> refreshBal.run());

        btn.addActionListener(e -> {
            if (accs.isEmpty()) { showError(parent, "No accounts available."); return; }
            double amt;
            try { amt = Double.parseDouble(amtField.getText().trim()); }
            catch (Exception ex) { showError(parent, "Enter a valid amount."); return; }
            if (amt <= 0) { showError(parent, "Amount must be greater than 0."); return; }

            CreatAccount acc = accs.get(accBox.getSelectedIndex());
            if (op.equals("deposit")) {
                acc.balance += amt;
                acc.addtoTransaction(new TransactionHistory(
                    (int)(Math.random()*100000), "Deposit", amt, java.time.LocalDateTime.now()));
            } else {
                if (amt > acc.getbalance()) { showError(parent, "Insufficient balance."); return; }
                acc.balance -= amt;
                acc.addtoTransaction(new TransactionHistory(
                    (int)(Math.random()*100000), "Withdrawal", amt, java.time.LocalDateTime.now()));
            }
            manager.saveData();
            amtField.setText("");
            // Update balance label immediately on same screen
            balLabel.setText("Current Balance: Rs." + String.format("%.2f", acc.getbalance()));
            showInfo(parent, label + " successful!\nNew Balance: Rs." + String.format("%.2f", acc.getbalance()));
        });

        p.add(card);
        return p;
    }

    // ── Transfer panel ────────────────────────────────────────────────────────
    static JPanel buildTransferPanel(JFrame parent) {
        JPanel p = darkPanel();
        p.setLayout(new GridBagLayout());

        JPanel card = roundedCard();
        card.setLayout(new GridBagLayout());
        GridBagConstraints g = gbc();

        List<CreatAccount> accs = currentUser.getaccounts();
        String[] accNums = accs.stream()
            .map(a -> a.getAccNumber() + "  (" + a.getClass().getSimpleName() + ")")
            .toArray(String[]::new);

        JComboBox<String> fromBox   = styledCombo(accNums);
        JTextField destAccField     = styledField();
        JTextField destNameField    = styledField();
        JTextField amtField         = styledField();

        g.gridy = 0; card.add(makeLabel("Transfer Money", FONT_TITLE, ACCENT), g);
        g.gridy = 1; card.add(Box.createVerticalStrut(12), g);
        addFormRow(card, g, 2, "From Account",             fromBox);
        addFormRow(card, g, 4, "Destination Account No.",  destAccField);
        addFormRow(card, g, 6, "Destination Holder Name",  destNameField);
        addFormRow(card, g, 8, "Amount (Rs.)",              amtField);

        g.gridy = 10; g.insets = new Insets(16, 0, 0, 0);
        JButton btn = primaryButton("Transfer");
        card.add(btn, g);

        btn.addActionListener(e -> {
            if (accs.isEmpty()) { showError(parent, "No accounts available."); return; }
            double amt;
            try { amt = Double.parseDouble(amtField.getText().trim()); }
            catch (Exception ex) { showError(parent, "Enter a valid amount."); return; }

            CreatAccount from = accs.get(fromBox.getSelectedIndex());
            if (amt <= 0 || amt > from.getbalance()) {
                showError(parent, "Invalid amount or insufficient balance."); return;
            }

            String destAcc  = destAccField.getText().trim();
            String destName = destNameField.getText().trim();
            boolean found   = false;

            for (User u : manager.users) {
                for (CreatAccount a : u.getaccounts()) {
                    if (a.getAccNumber().equals(destAcc) && u.getusername().equalsIgnoreCase(destName)) {
                        from.balance -= amt;
                        a.balance    += amt;
                        from.addtoTransaction(new TransactionHistory(
                            (int)(Math.random()*100000), "Transfer Out", amt, java.time.LocalDateTime.now()));
                        a.addtoTransaction(new TransactionHistory(
                            (int)(Math.random()*100000), "Transfer In",  amt, java.time.LocalDateTime.now()));
                        found = true; break;
                    }
                }
                if (found) break;
            }

            if (!found) { showError(parent, "Destination account not found."); return; }
            manager.saveData();
            showInfo(parent, "Transfer of Rs." + String.format("%.2f", amt) + " successful!");
            amtField.setText(""); destAccField.setText(""); destNameField.setText("");
        });

        p.add(card);
        return p;
    }

    // ── Transaction history panel ─────────────────────────────────────────────
    static JPanel buildTxPanel() {
        JPanel p = darkPanel();
        p.setLayout(new BorderLayout());
        p.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        p.add(makeLabel("Transaction History", FONT_TITLE, TEXT), BorderLayout.NORTH);

        JTextArea area = new JTextArea();
        area.setFont(FONT_MONO);
        area.setBackground(PANEL);
        area.setForeground(TEXT);
        area.setEditable(false);
        area.setBorder(BorderFactory.createEmptyBorder(12, 12, 12, 12));

        StringBuilder sb = new StringBuilder();
        for (CreatAccount acc : currentUser.getaccounts()) {
            sb.append("━━━  ").append(acc.getClass().getSimpleName())
              .append("  [").append(acc.getAccNumber()).append("]  ━━━\n");
            sb.append("  Balance : Rs.").append(String.format("%.2f", acc.getbalance())).append("\n\n");
        }
        if (sb.length() == 0) sb.append("No accounts found.");
        area.setText(sb.toString());

        JScrollPane scroll = new JScrollPane(area);
        scroll.setOpaque(false);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(51, 65, 85)));
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ── Monthly statement panel ───────────────────────────────────────────────
    static JPanel buildStatementPanel() {
        JPanel p = darkPanel();
        p.setLayout(new BorderLayout());
        p.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));
        p.add(makeLabel("Monthly Statement", FONT_TITLE, TEXT), BorderLayout.NORTH);

        JPanel inner = darkPanel();
        inner.setLayout(new BoxLayout(inner, BoxLayout.Y_AXIS));
        inner.setBorder(BorderFactory.createEmptyBorder(16, 0, 0, 0));

        for (CreatAccount acc : currentUser.getaccounts()) {
            JPanel card = roundedCard();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.add(makeLabel(acc.getClass().getSimpleName() + "  [" + acc.getAccNumber() + "]", FONT_LABEL, ACCENT));
            card.add(Box.createVerticalStrut(6));
            card.add(makeLabel("Holder  : " + currentUser.getusername(), FONT_BODY, TEXT));
            card.add(makeLabel("Balance : Rs. " + String.format("%.2f", acc.getbalance()), FONT_BODY, ACCENT2));
            card.add(Box.createVerticalStrut(4));
            String note = "";
            if      (acc instanceof savingAccount)   note = "Interest Rate : 3% per month";
            else if (acc instanceof studentAccount)  note = "Interest Rate : 8% per month";
            else if (acc instanceof FixedDeposite)   note = "Interest Rate : Tiered (7% – 20%)";
            else if (acc instanceof checkingAccount) note = "Overdraft     : Up to Rs.10,000";
            if (!note.isEmpty()) card.add(makeLabel(note, FONT_SMALL, SUBTEXT));
            inner.add(card);
            inner.add(Box.createVerticalStrut(10));
        }

        JScrollPane scroll = new JScrollPane(inner);
        scroll.setOpaque(false);
        scroll.getViewport().setOpaque(false);
        scroll.setBorder(null);
        p.add(scroll, BorderLayout.CENTER);
        return p;
    }

    // ── New account panel ────────────────────────────────────────────────────
    static JPanel buildNewAccountPanel(JFrame parent) {
        JPanel p = darkPanel();
        p.setLayout(new GridBagLayout());

        JPanel card = roundedCard();
        card.setLayout(new GridBagLayout());
        GridBagConstraints g = gbc();

        JTextField accField     = styledField();
        JPasswordField pinField = styledPass();
        JTextField balField     = styledField();
        String[] types = {"Savings Account", "Checking Account", "Student Account", "Fixed Deposit Account"};
        JComboBox<String> typeBox = styledCombo(types);

        g.gridy = 0; card.add(makeLabel("Open New Account", FONT_TITLE, ACCENT), g);
        g.gridy = 1; card.add(Box.createVerticalStrut(12), g);
        addFormRow(card, g, 2, "Account Number",        accField);
        addFormRow(card, g, 4, "PIN",                   pinField);
        addFormRow(card, g, 6, "Opening Balance (Rs.)", balField);
        addFormRow(card, g, 8, "Account Type",          typeBox);

        g.gridy = 10; g.insets = new Insets(16, 0, 0, 0);
        JButton btn = primaryButton("Open Account");
        card.add(btn, g);

        btn.addActionListener(e -> {
            String accNum = accField.getText().trim();
            String pin    = new String(pinField.getPassword()).trim();
            String balStr = balField.getText().trim();
            if (accNum.isEmpty() || pin.isEmpty() || balStr.isEmpty()) {
                showError(parent, "Please fill all fields."); return;
            }
            double bal;
            try { bal = Double.parseDouble(balStr); } catch (Exception ex) {
                showError(parent, "Invalid balance."); return;
            }
            for (User u : manager.users) {
                for (CreatAccount a : u.getaccounts()) {
                    if (a.getAccNumber().equals(accNum)) {
                        showError(parent, "Account number already exists."); return;
                    }
                }
            }
            CreatAccount account = buildAccount(typeBox.getSelectedIndex() + 1,
                currentUser.getusername(), accNum, pin, bal);
            if (account == null) { showError(parent, "Error creating account."); return; }
            currentUser.addAccount(account);
            manager.saveData();
            showInfo(parent, "New account opened!\nAccount Number: " + accNum);
            accField.setText(""); balField.setText(""); pinField.setText("");
        });

        p.add(card);
        return p;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  ACCOUNT BUILDER (no Scanner — uses direct setters)
    // ════════════════════════════════════════════════════════════════════════
    static CreatAccount buildAccount(int type, String username, String accNum, String pin, double balance) {
        CreatAccount acc = null;
        switch (type) {
            case 1:
                savingAccount sa = new savingAccount();
                sa.startDate = java.time.LocalDate.now();
                acc = sa; break;
            case 2:
                acc = new checkingAccount(); break;
            case 3:
                studentAccount st = new studentAccount();
                st.startDate = java.time.LocalDate.now();
                acc = st; break;
            case 4:
                FixedDeposite fd = new FixedDeposite();
                fd.setMonthsReflect(12L);
                fd.setStartMonths();
                acc = fd; break;
            default: return null;
        }
        acc.setUsername(username);
        acc.setAccNumDirectly(accNum);
        acc.setPinDirectly(pin);
        acc.balance = balance;
        return acc;
    }

    // ════════════════════════════════════════════════════════════════════════
    //  UI HELPERS
    // ════════════════════════════════════════════════════════════════════════
    static JFrame makeFrame(String title, int w, int h) {
        JFrame f = new JFrame(title);
        f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        f.setSize(w, h);
        f.setLocationRelativeTo(null);
        f.setResizable(false);
        return f;
    }
    static JPanel darkPanel() {
        JPanel p = new JPanel(); p.setBackground(BG); return p;
    }
    static JPanel roundedCard() {
        JPanel card = new JPanel() {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(PANEL);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 16, 16);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        card.setOpaque(false);
        card.setBorder(BorderFactory.createEmptyBorder(20, 24, 20, 24));
        return card;
    }
    static JLabel makeLabel(String text, Font font, Color color) {
        JLabel l = new JLabel(text); l.setFont(font); l.setForeground(color); return l;
    }
    static JTextField styledField() {
        JTextField f = new JTextField(22);
        f.setBackground(new Color(15, 23, 42));
        f.setForeground(TEXT); f.setCaretColor(ACCENT); f.setFont(FONT_BODY);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(51, 65, 85), 1, true),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)));
        return f;
    }
    static JPasswordField styledPass() {
        JPasswordField f = new JPasswordField(22);
        f.setBackground(new Color(15, 23, 42));
        f.setForeground(TEXT); f.setCaretColor(ACCENT); f.setFont(FONT_BODY);
        f.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(51, 65, 85), 1, true),
            BorderFactory.createEmptyBorder(6, 10, 6, 10)));
        return f;
    }
    static <T> JComboBox<T> styledCombo(T[] items) {
        JComboBox<T> c = new JComboBox<>(items);
        c.setBackground(PANEL); c.setForeground(TEXT); c.setFont(FONT_BODY);
        c.setPreferredSize(new Dimension(260, 32));
        return c;
    }
    static JButton primaryButton(String text) {
        JButton b = new JButton(text) {
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(getModel().isPressed() ? ACCENT.darker()
                           : getModel().isRollover() ? ACCENT.brighter() : ACCENT);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 10, 10);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        b.setForeground(BG); b.setFont(FONT_LABEL);
        b.setPreferredSize(new Dimension(260, 38));
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        return b;
    }
    static JButton ghostButton(String text) {
        JButton b = new JButton(text);
        b.setForeground(SUBTEXT); b.setFont(FONT_SMALL);
        b.setBackground(BG); b.setBorderPainted(false);
        b.setContentAreaFilled(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setPreferredSize(new Dimension(260, 28));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setForeground(TEXT); }
            public void mouseExited (MouseEvent e) { b.setForeground(SUBTEXT); }
        });
        return b;
    }
    static JButton navButton(String text) {
        JButton b = new JButton(text);
        b.setForeground(TEXT); b.setFont(FONT_BODY);
        b.setBackground(PANEL);
        b.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
        b.setHorizontalAlignment(SwingConstants.LEFT);
        b.setContentAreaFilled(false); b.setBorderPainted(false); b.setFocusPainted(false);
        b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        b.setMaximumSize(new Dimension(Integer.MAX_VALUE, 36));
        b.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { b.setForeground(ACCENT); }
            public void mouseExited (MouseEvent e) { b.setForeground(TEXT); }
        });
        return b;
    }
    static GridBagConstraints gbc() {
        GridBagConstraints g = new GridBagConstraints();
        g.gridx = 0; g.gridy = 0;
        g.anchor = GridBagConstraints.WEST;
        g.fill   = GridBagConstraints.HORIZONTAL;
        g.weightx = 1.0;
        g.insets  = new Insets(0, 0, 0, 0);
        return g;
    }
    static void addFormRow(JPanel p, GridBagConstraints g, int row, String label, JComponent field) {
        g.gridy = row;     g.insets = new Insets(0, 0, 2,  0); p.add(makeLabel(label, FONT_LABEL, TEXT), g);
        g.gridy = row + 1; g.insets = new Insets(0, 0, 10, 0); p.add(field, g);
    }
    static void showError(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }
    static void showInfo(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Success", JOptionPane.INFORMATION_MESSAGE);
    }
}
