package bank;

import java.util.Scanner;


public class  Login extends readAccount {
	public static void main(String[] args) {
		boolean found = false;
		Scanner input=new Scanner(System.in);
		Login log=new Login();
		log.readData();
		System.out.println("Enter the Account Number");
		String h=input.nextLine();
		System.out.println("Enter the Account Pin");
		String d=input.nextLine();
		for(CreatAccount acc:log.accounts) {
			if(acc.getAccNumber().equals(h)&&acc.getPin().equals(d)) {
				System.out.println("Sucsessfully Login");
				found=true;
				break;
			}
			
			}
		if(!found) {
			System.out.println("Incorrect AccountName or Pin");
			}
		input.close();	
		}
		
}
	
