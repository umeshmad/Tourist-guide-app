package bank;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

public class saveAccount { 
	
    public static void saveAccount(CreatAccount acc) {
        
        try {
        	ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("bank.dat"));
        	oos.writeObject(acc);
        	oos.close();
        	System.out.println("Data saved Successfully");
        }catch(IOException e){
        	System.out.println("Error in saving files "+e.getMessage());
        }
        
    } 
} 