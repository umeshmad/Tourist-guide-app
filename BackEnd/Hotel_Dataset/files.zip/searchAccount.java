package bank;

import java.util.Scanner;

public class searchAccount extends readAccount {
	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		System.out.println("Enter the Accountnumber");
		searchAccount search=new searchAccount();
		search.readData();
		String q=input.nextLine();
		for(CreatAccount acc : search.accounts) {
			if(acc.getAccNumber().equals(q)) {
				System.out.println("Account Number : "+acc.getAccNumber());
				System.out.println("Account Name : "+acc.getUsername());
				System.out.println("Account Balance : "+acc.getbalance());
				System.out.println("Account Pin : "+acc.getPin());
				break;
			}
			System.out.println("NO Account Exsit in the System");
			
		}
		}
	} 
	
