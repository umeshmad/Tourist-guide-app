package bank;
import java.io.Serializable;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class CreatAccount implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String accountNumber;
	private String pin;
	protected double balance;
	private String username; 
	private List<TransactionHistory> trans;
	
	transient Scanner input = new Scanner(System.in);
	
	public CreatAccount() {
		trans = new ArrayList<>();
	}
	
	public void addtoTransaction(TransactionHistory tran) {
		trans.add(tran);
	}
	
	// Print all transactions for this account
	public void printTransactions() {
		if (trans == null || trans.isEmpty()) {
			System.out.println("No transactions found.");
			return;
		}
		System.out.println("Transaction History:");
		for (TransactionHistory t : trans) {
			System.out.println("  ID: " + t.getTransId()
				+ " | Type: " + t.getType()
				+ " | Amount: Rs." + t.getamount()
				+ " | Date: " + t.gettime());
		}
	}
	
	public void setAccNum() {
		System.out.println("Enter the Account Number : ");
		String H = input.nextLine();
		accountNumber = H;
	}
	// Direct setter used by GUI (no Scanner)
	public void setAccNumDirectly(String accNum) {
		this.accountNumber = accNum;
	}
	// Direct setter used by GUI (no Scanner)
	public void setPinDirectly(String pin) {
		this.pin = pin;
	}
	
	public void setUsername(String username) {
		this.username = username;
	}

	public String getUsername() {
		return username;
	}
	
	public void setBalance() {
		System.out.println("Enter the Balance : ");
		double P = input.nextDouble();
		balance = P;
		input.nextLine();
	}
	
	public void setPin() {
		System.out.println("Enter the Pin Number : ");
		String L = input.nextLine();
		pin = L;
	}
	
	public void setInterstBalance(double interstMoney) {
		balance = balance + interstMoney;	
	}
	
	public void reduceInterstBalance(double interstMoney) {
		balance = balance - interstMoney;	
	}
	
	public void transermoney(double transmoney) {
		balance = transmoney;
	}
	
	public double getbalance() {
		return balance;
	}
	
	public String getAccNumber() {
		return accountNumber;
	}
	
	public String getPin() {
		return pin;
	}

	public void deposite() {
		System.out.println("Enter the Deposite ammount");
		double r = input.nextDouble();
		input.nextLine();
		if (r > 0) {
			balance += r;
			// Record transaction
			trans.add(new TransactionHistory(trans.size() + 1, "Deposit", r, java.time.LocalDateTime.now()));
			System.out.println("Your balance is Rs." + balance);
		} else {
			System.out.println("Enter the valid Ammount");
		}
	}
	
	public void withdraw() {
		System.out.println("Enter the Withdraw ammount");
		double x = input.nextDouble();
		input.nextLine();
		if (x <= balance) {
			balance -= x;
			// Record transaction
			trans.add(new TransactionHistory(trans.size() + 1, "Withdrawal", x, java.time.LocalDateTime.now()));
			System.out.println("Your balance is Rs." + balance);
		} else {
			System.out.println("Not Enough money in the account your current balance is Rs." + balance);	
		}
	}
}
