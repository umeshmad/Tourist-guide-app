package bank;

import java.io.*;
import java.util.ArrayList;

// Manages saving and reading the list of all Users (each user can have multiple accounts)
public class UserManager {
    protected ArrayList<User> users;

    public UserManager() {
        users = new ArrayList<>();
    }

    // Read all users from file
    public void readData() {
        try {
            ObjectInputStream ois = new ObjectInputStream(new FileInputStream("bankusers.dat"));
            users = (ArrayList<User>) ois.readObject();
            ois.close();
        } catch (FileNotFoundException e) {
            // No data yet, start fresh
            users = new ArrayList<>();
        } catch (Exception e) {
            System.out.println("Error reading data: " + e.getMessage());
            users = new ArrayList<>();
        }
    }

    // Save all users to file
    public void saveData() {
        try {
            ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("bankusers.dat"));
            oos.writeObject(users);
            oos.close();
            System.out.println("Data saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving data: " + e.getMessage());
        }
    }
}
