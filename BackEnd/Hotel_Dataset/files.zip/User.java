package bank;
import java.io.Serializable;
import java.util.List;
import java.util.ArrayList;
import java.util.Scanner;

public class User implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private String username;
	private List<CreatAccount> accounts;
	
	public void setuser() {
		Scanner input = new Scanner(System.in);
		username = input.nextLine();
	}
	
	// Set username directly (used during registration)
	public void setUsernameDirectly(String name) {
		this.username = name;
	}
	
	public String getusername() {
		return username;
	}
	
	public User() {
		accounts = new ArrayList<>();
	}
	
	public void addAccount(CreatAccount account) {
		accounts.add(account);
	}
	
	public List<CreatAccount> getaccounts() {
		return accounts;
	}
}
